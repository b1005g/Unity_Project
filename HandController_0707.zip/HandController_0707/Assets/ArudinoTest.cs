﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class ArudinoTest : MonoBehaviour
{
    SerialPort sp = new SerialPort("\\\\.\\COM10", 115200);    //아두이노 포트가 10이상이면 \\\\.\\를 COM 앞에 붙여주세요.

    int val = 0;

    int acc = 5;

    // Use this for initialization

    void Start()
    {

        sp.Open();

        sp.ReadTimeout = 50;

    }



    // Update is called once per frame

    void Update()
    {

        if (sp.IsOpen)

        {

            try

            {

                sp.Write("s");

                val = sp.ReadByte();

                Debug.Log(val);

                if ((val & 0x01) == 0x01)

                {

                    transform.Translate(Vector3.forward * Time.deltaTime * acc);

                }

                else if ((val & 0x02) == 0x02)

                {

                    transform.Translate(Vector3.back * Time.deltaTime * acc);

                }

                if ((val & 0x04) == 0x04)

                {

                    transform.Translate(Vector3.right * Time.deltaTime * acc);

                }

                else if ((val & 0x08) == 0x08)

                {

                    transform.Translate(Vector3.left * Time.deltaTime * acc);

                }

            }

            catch (System.Exception) { }

        }

    }

}

