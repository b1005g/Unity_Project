﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp_test
{
    public partial class Frm_test : Form
    {
        int a = 0; // 멤버 변수
        int b = 0;
        DateTime startDateTime;
        public Frm_test()
        {
            InitializeComponent();
            startDateTime = DateTime.Now;
        }
        
        public DateTime GetStartDateTime()
        {
            return startDateTime;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(GetStartDateTime().ToString());
            MessageBox.Show("노무현 운지 ㅠㅠ");
        }

        private void Frm_test_Load(object sender, EventArgs e)
        {

        }
    }
}
