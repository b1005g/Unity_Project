﻿
namespace WindowsFormsApp_test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_first = new System.Windows.Forms.Button();
            this.btn_second = new System.Windows.Forms.Button();
            this.btn_thrid = new System.Windows.Forms.Button();
            this.btn_four = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // btn_first
            // 
            this.btn_first.Font = new System.Drawing.Font("배달의민족 도현", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_first.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btn_first.Location = new System.Drawing.Point(57, 63);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(276, 123);
            this.btn_first.TabIndex = 0;
            this.btn_first.Text = "버튼";
            this.btn_first.UseVisualStyleBackColor = true;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // btn_second
            // 
            this.btn_second.Location = new System.Drawing.Point(408, 63);
            this.btn_second.Name = "btn_second";
            this.btn_second.Size = new System.Drawing.Size(278, 122);
            this.btn_second.TabIndex = 1;
            this.btn_second.Text = "button1";
            this.btn_second.UseVisualStyleBackColor = true;
            this.btn_second.Click += new System.EventHandler(this.btn_second_Click);
            // 
            // btn_thrid
            // 
            this.btn_thrid.Font = new System.Drawing.Font("배달의민족 도현", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_thrid.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btn_thrid.Location = new System.Drawing.Point(57, 243);
            this.btn_thrid.Name = "btn_thrid";
            this.btn_thrid.Size = new System.Drawing.Size(276, 123);
            this.btn_thrid.TabIndex = 2;
            this.btn_thrid.Text = "버튼";
            this.btn_thrid.UseVisualStyleBackColor = true;
            this.btn_thrid.Click += new System.EventHandler(this.btn_thrid_Click);
            // 
            // btn_four
            // 
            this.btn_four.Font = new System.Drawing.Font("배달의민족 도현", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_four.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btn_four.Location = new System.Drawing.Point(408, 243);
            this.btn_four.Name = "btn_four";
            this.btn_four.Size = new System.Drawing.Size(278, 123);
            this.btn_four.TabIndex = 3;
            this.btn_four.Text = "버튼";
            this.btn_four.UseVisualStyleBackColor = true;
            this.btn_four.Click += new System.EventHandler(this.btn_four_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(67, 395);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(103, 15);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "www.ssu.ac.kr";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.btn_four);
            this.Controls.Add(this.btn_thrid);
            this.Controls.Add(this.btn_second);
            this.Controls.Add(this.btn_first);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_first;
        private System.Windows.Forms.Button btn_second;
        private System.Windows.Forms.Button btn_thrid;
        private System.Windows.Forms.Button btn_four;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}